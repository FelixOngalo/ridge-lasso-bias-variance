# Ridge, Lasso and the Bias-Variance Trade-off

**Question:** *(fill in)* When there are many correlated predictors and few observations, how much does shrinkage help, why does it help, and how well can the lasso recover which variables really matter?

**Key findings:** *(fill in after running the analysis; 2-3 bullets with numbers: best ridge/lasso test error versus OLS, the lambda that minimised it, lasso precision and recall)*

**Tools:** R, base linear algebra (SVD, `solve`), dplyr, tibble, ggplot2, Quarto. No modelling packages: ridge, lasso and cross-validation are implemented from scratch.

## Reproduce

1. `install.packages(c("dplyr", "tidyr", "tibble", "ggplot2", "knitr", "quarto"))`
2. From the project root, run `R/01_run_experiments.R` (about a few minutes; it saves `data/clean/verification_results.rds`)
3. Render `reports/report.qmd`

All data are simulated inside the script, so no download is needed.

## Key concepts

- **Ridge** has a closed form, and in the SVD basis multiplies each OLS component by d²/(d² + nλ), shrinking low-variance directions most.
- **Hoerl-Kennard theorem:** the ridge error has strictly negative slope at λ = 0, so some λ > 0 always beats OLS.
- **Lasso** has no closed form but is solved exactly one coordinate at a time by soft-thresholding; optimality is checked with the KKT conditions.
- **Orthonormal design:** lasso = soft-thresholded OLS, ridge = OLS/(1+λ).
- **Bias-variance decomposition** measured by redrawing noise on a fixed design, and compared against exact ridge formulas.
- **Cross-validation** with the minimum and the 1-standard-error rule, graded on support recovery (precision, recall).

## Project structure

```
R/regularization_functions.R   ridge, lasso (coordinate descent), KKT check, CV, exact ridge bias/variance
R/01_run_experiments.R         theory checks, bias-variance simulation, estimator comparison
reports/report.qmd             proofs, results and interpretation prompts
data/clean/                    saved results (generated)
```

## Limitations

*(fill in; see the Limitations section of the report: single simulation design, standardisation leakage in CV, teaching-grade implementation, Monte Carlo noise)*
