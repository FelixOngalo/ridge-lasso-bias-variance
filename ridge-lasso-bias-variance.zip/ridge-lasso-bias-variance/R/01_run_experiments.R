library(dplyr)
library(tibble)
source("R/regularization_functions.R")
set.seed(42)

n <- 100; p <- 50; sigma <- 3
TRUE_BETA <- numeric(p); TRUE_BETA[c(1, 2, 5, 10, 20)] <- c(3, -2, 1.5, 2, -1.5)   # 5 nonzero of 50

# ---------------------------------------------------------------------
cat("=== 1. Checking the mathematics on one dataset ===\n")
X <- standardize(make_design(n, p))$X
y <- as.vector(X %*% TRUE_BETA + rnorm(n, sd = sigma))
lam <- 0.1

ridge_closed <- ridge_fit(X, y, lam)
ridge_via_svd <- ridge_svd(X, y, lam)
cat("Ridge: closed form vs SVD form, max abs difference:", format(max(abs(ridge_closed - ridge_via_svd)), digits = 3), "\n")

# Shrinkage-factor identity: ridge coefficient components in the singular basis
# equal the OLS components times d^2 / (d^2 + n lambda).
s <- svd(X)
ols_components   <- as.vector(crossprod(s$v, ols_fit(X, y)))
ridge_components <- as.vector(crossprod(s$v, ridge_closed))
shrink_gap <- max(abs(ridge_components - ridge_shrinkage(X, lam, s) * ols_components))
cat("Ridge = OLS x d^2/(d^2 + n lambda) in the V basis, max abs difference:", format(shrink_gap, digits = 3), "\n")

lasso_beta <- lasso_cd(X, y, lam)
kkt <- lasso_kkt_violation(X, y, lasso_beta, lam)
cat("Lasso: nonzeros =", sum(lasso_beta != 0), " largest KKT violation =", format(kkt, digits = 3), "\n")

obj0 <- lasso_objective(X, y, lasso_beta, lam)
perturbed <- replicate(2000, lasso_objective(X, y, lasso_beta + rnorm(p, sd = 0.01) * (runif(p) < 0.3), lam))
cat("Lasso objective at solution:", round(obj0, 6), " lowest objective among 2000 random perturbations:", round(min(perturbed), 6), "\n")

# Orthonormal design: lasso must equal soft-thresholded least squares, ridge must equal OLS / (1 + lambda).
Q <- qr.Q(qr(matrix(rnorm(n * p), n, p))) * sqrt(n)      # (1/n) Q'Q = I
z <- as.vector(crossprod(Q, y)) / n                       # the OLS coefficients
ortho <- tibble(
  lasso_gap = max(abs(lasso_cd(Q, y, lam) - soft_threshold(z, lam))),
  ridge_gap = max(abs(ridge_fit(Q, y, lam) - z / (1 + lam))))
cat("Orthonormal design, lasso vs soft-threshold gap:", format(ortho$lasso_gap, digits = 3),
    " ridge vs z/(1+lambda) gap:", format(ortho$ridge_gap, digits = 3), "\n")

lmax <- max(abs(crossprod(X, y))) / n
cat("Lasso at lambda_max =", round(lmax, 4), ": nonzeros =", sum(lasso_cd(X, y, lmax * 1.0001) != 0), "(should be 0)\n")

verification <- tibble(
  check = c("Ridge closed form = SVD form", "Ridge shrinkage factors d^2/(d^2 + n lambda)",
            "Lasso largest KKT violation", "Orthonormal design: lasso = soft-threshold",
            "Orthonormal design: ridge = OLS/(1+lambda)"),
  max_abs_gap = c(max(abs(ridge_closed - ridge_via_svd)), shrink_gap, kkt, ortho$lasso_gap, ortho$ridge_gap))

# ---------------------------------------------------------------------
cat("\n=== 2. Bias-variance trade-off with the design FIXED and only the noise redrawn ===\n")
set.seed(1)
raw_train <- make_design(n, p)
st <- standardize(raw_train)
X <- st$X
X_test <- standardize(make_design(500, p), st$center, st$scale)$X
f_test <- as.vector(X_test %*% TRUE_BETA)
sv <- svd(X)

ridge_lams <- exp(seq(log(10), log(1e-3), length.out = 25))
y_probe <- as.vector(X %*% TRUE_BETA + rnorm(n, sd = sigma))
lasso_lams <- lambda_grid(X, y_probe, 25)

R <- 200
sum_r <- sum2_r <- matrix(0, 500, length(ridge_lams))
sum_l <- sum2_l <- matrix(0, 500, length(lasso_lams))
sum_o <- sum2_o <- numeric(500)
for (r in seq_len(R)) {
  y <- as.vector(X %*% TRUE_BETA + rnorm(n, sd = sigma))
  P_r <- X_test %*% vapply(ridge_lams, function(l) ridge_svd(X, y, l, sv), numeric(p))
  P_l <- X_test %*% lasso_path(X, y, lasso_lams)
  P_o <- as.vector(X_test %*% ols_fit(X, y))
  sum_r <- sum_r + P_r; sum2_r <- sum2_r + P_r^2
  sum_l <- sum_l + P_l; sum2_l <- sum2_l + P_l^2
  sum_o <- sum_o + P_o; sum2_o <- sum2_o + P_o^2
}
decompose <- function(s1, s2, f) {
  m <- s1 / R
  tibble(bias2 = colMeans((m - f)^2), variance = colMeans(s2 / R - m^2))
}
bv_ridge <- bind_cols(tibble(method = "Ridge", lambda = ridge_lams), decompose(sum_r, sum2_r, f_test))
bv_lasso <- bind_cols(tibble(method = "Lasso", lambda = lasso_lams), decompose(sum_l, sum2_l, f_test))
bv_ols <- tibble(bias2 = mean((sum_o / R - f_test)^2), variance = mean(sum2_o / R - (sum_o / R)^2))
bv <- bind_rows(bv_ridge, bv_lasso) |> mutate(total = bias2 + variance)
cat("OLS (lambda = 0): bias^2 =", round(bv_ols$bias2, 3), " variance =", round(bv_ols$variance, 3),
    " total =", round(bv_ols$bias2 + bv_ols$variance, 3), "\n")
print(bv |> group_by(method) |> slice_min(total, n = 1) |> select(method, lambda, bias2, variance, total))

# Exact (no simulation) ridge bias/variance from the formulas, to compare with the simulation
ridge_exact <- bind_rows(lapply(ridge_lams, function(l) {
  v <- ridge_exact_bias_variance(X, X_test, TRUE_BETA, sigma, l)
  tibble(lambda = l, bias2_exact = v[["bias2"]], variance_exact = v[["variance"]])
})) |> mutate(total_exact = bias2_exact + variance_exact)
sim_vs_exact <- bv_ridge |> left_join(ridge_exact, by = "lambda") |>
  mutate(total = bias2 + variance, total_gap = total - total_exact)
cat("Largest gap between simulated and exact ridge total error:", round(max(abs(sim_vs_exact$total_gap)), 4), "\n")

# Hoerl-Kennard: the exact ridge MSE decreases at lambda = 0+, so SOME ridge beats OLS.
ols_exact <- ridge_exact_bias_variance(X, X_test, TRUE_BETA, sigma, 1e-10)
eps_exact <- ridge_exact_bias_variance(X, X_test, TRUE_BETA, sigma, 1e-3)
cat("Exact test error at lambda ~ 0:", round(sum(ols_exact), 4), " at lambda = 0.001:", round(sum(eps_exact), 4), "\n")

# ---------------------------------------------------------------------
cat("\n=== 3. Estimators compared with cross-validated lambda (new data every replication) ===\n")
set.seed(2026)
R2 <- 60
true_support <- which(TRUE_BETA != 0)
one_rep <- function() {
  st <- standardize(make_design(n, p)); X <- st$X
  X_test <- standardize(make_design(1000, p), st$center, st$scale)$X
  f_test <- as.vector(X_test %*% TRUE_BETA)
  y <- as.vector(X %*% TRUE_BETA + rnorm(n, sd = sigma))

  cv_l <- kfold_cv(X, y, lasso_path, lambda_grid(X, y, 25), K = 5, seed = 1)
  cv_r <- kfold_cv(X, y, ridge_path, ridge_lams, K = 5, seed = 1)
  fits <- list(
    `OLS` = ols_fit(X, y),
    `Ridge (CV min)` = ridge_fit(X, y, cv_r$lambda_min),
    `Lasso (CV min)` = lasso_cd(X, y, cv_l$lambda_min),
    `Lasso (CV 1-SE)` = lasso_cd(X, y, cv_l$lambda_1se),
    `Oracle OLS on true support` = { b <- numeric(p); b[true_support] <- ols_fit(X[, true_support], y); b })
  bind_rows(lapply(names(fits), function(nm) {
    b <- fits[[nm]]
    sel <- which(b != 0)
    tibble(method = nm,
           signal_mse = mean((X_test %*% b - f_test)^2),
           coef_error = sum((b - TRUE_BETA)^2),
           n_selected = length(sel),
           precision = if (length(sel) > 0) mean(sel %in% true_support) else NA_real_,
           recall = mean(true_support %in% sel))
  }))
}
comparison <- bind_rows(lapply(seq_len(R2), function(i) one_rep() |> mutate(rep = i)))
comparison_summary <- comparison |>
  group_by(method) |>
  summarise(signal_mse = mean(signal_mse), coef_error = mean(coef_error),
            n_selected = mean(n_selected), precision = mean(precision, na.rm = TRUE),
            recall = mean(recall), .groups = "drop") |>
  arrange(signal_mse)
print(comparison_summary)

# One CV curve for the report
set.seed(5)
X <- standardize(make_design(n, p))$X
y <- as.vector(X %*% TRUE_BETA + rnorm(n, sd = sigma))
lg <- lambda_grid(X, y, 25)
cv_curve <- kfold_cv(X, y, lasso_path, lg, K = 5, seed = 1)
cv_df <- tibble(lambda = lg, cv_mean = cv_curve$cv_mean, cv_se = cv_curve$cv_se)
path_beta <- lasso_path(X, y, lg)
path_df <- bind_rows(lapply(seq_len(p), function(j) tibble(lambda = lg, coefficient = path_beta[j, ], variable = j, true_nonzero = TRUE_BETA[j] != 0)))

saveRDS(list(verification = verification, bv = bv, bv_ols = bv_ols, ridge_exact = ridge_exact,
             sim_vs_exact = sim_vs_exact, comparison_summary = comparison_summary, R = R, R2 = R2,
             cv_df = cv_df, cv_choice = c(min = cv_curve$lambda_min, one_se = cv_curve$lambda_1se),
             path_df = path_df, sigma = sigma, n = n, p = p,
             hk = c(near_zero = sum(ols_exact), small = sum(eps_exact))),
        "data/clean/verification_results.rds")
