# Ordinary least squares, ridge and lasso written from scratch in base R,
# plus the cross-validation and simulation machinery to compare them.
#
# CONVENTIONS. Predictors are standardized: every column has mean 0 and
# mean square 1, (1/n) sum_i x_ij^2 = 1. Because columns are centered,
# the intercept is just mean(y), so all models below are fit WITHOUT an
# intercept (y is not centered; the true intercept in the simulation is
# zero). The two penalized objectives are
#   ridge:  (1/(2n)) ||y - X b||^2 + (lambda/2) ||b||_2^2
#   lasso:  (1/(2n)) ||y - X b||^2 +  lambda   ||b||_1
# so that lambda means the same kind of thing in both.

# ---- helpers -----------------------------------------------------------

#' Center and scale columns to mean square 1. Pass the training
#' `center` and `scale` back in to transform test data identically.
standardize <- function(X, center = NULL, scale = NULL) {
  if (is.null(center)) center <- colMeans(X)
  Xc <- sweep(X, 2, center)
  if (is.null(scale)) scale <- sqrt(colMeans(Xc^2))
  list(X = sweep(Xc, 2, scale, "/"), center = center, scale = scale)
}

#' Soft-thresholding: the exact solution of min_b 0.5 (z - b)^2 + gamma |b|.
soft_threshold <- function(z, gamma) sign(z) * pmax(abs(z) - gamma, 0)

#' Correlated Gaussian predictors with AR(1) correlation rho^|j - k|.
make_design <- function(n, p, rho = 0.5) {
  Z <- matrix(rnorm(n * p), n, p)
  X <- Z
  for (j in 2:p) X[, j] <- rho * X[, j - 1] + sqrt(1 - rho^2) * Z[, j]
  X
}

# ---- OLS and ridge -----------------------------------------------------

ols_fit <- function(X, y) as.vector(solve(crossprod(X), crossprod(X, y)))

#' Ridge in closed form: b = (X'X/n + lambda I)^-1 X'y/n.
ridge_fit <- function(X, y, lambda) {
  n <- nrow(X); p <- ncol(X)
  as.vector(solve(crossprod(X) / n + lambda * diag(p), crossprod(X, y) / n))
}

#' The same ridge solution through the SVD X = U D V': b = V diag(d/(d^2 + n lambda)) U'y.
#' Each OLS component along singular direction i is multiplied by the
#' shrinkage factor d_i^2 / (d_i^2 + n lambda), see ridge_shrinkage().
ridge_svd <- function(X, y, lambda, s = svd(X)) {
  n <- nrow(X)
  as.vector(s$v %*% ((s$d / (s$d^2 + n * lambda)) * crossprod(s$u, y)))
}

ridge_shrinkage <- function(X, lambda, s = svd(X)) s$d^2 / (s$d^2 + nrow(X) * lambda)

ridge_path <- function(X, y, lambdas) {
  s <- svd(X)
  vapply(lambdas, function(l) ridge_svd(X, y, l, s), numeric(ncol(X)))   # p x L
}

# ---- lasso by cyclic coordinate descent ------------------------------

#' For coordinate j, holding the others fixed, the objective is
#' 0.5 (rho_j - b_j)^2 + lambda |b_j| + const, with
#' rho_j = (1/n) x_j'(partial residual) = (1/n) x_j' r + b_j (current b_j),
#' whose minimizer is soft_threshold(rho_j, lambda). Sweep until no
#' coefficient moves by more than `tol`. Requires standardized columns.
lasso_cd <- function(X, y, lambda, beta = NULL, max_iter = 5000, tol = 1e-9) {
  n <- nrow(X); p <- ncol(X)
  if (is.null(beta)) beta <- numeric(p)
  r <- as.vector(y - X %*% beta)
  for (it in seq_len(max_iter)) {
    max_change <- 0
    for (j in seq_len(p)) {
      xj <- X[, j]
      rho <- sum(xj * r) / n + beta[j]
      b_new <- soft_threshold(rho, lambda)
      if (b_new != beta[j]) {
        r <- r - xj * (b_new - beta[j])
        max_change <- max(max_change, abs(b_new - beta[j]))
        beta[j] <- b_new
      }
    }
    if (max_change < tol) break
  }
  beta
}

lasso_objective <- function(X, y, beta, lambda) sum((y - X %*% beta)^2) / (2 * nrow(X)) + lambda * sum(abs(beta))

#' Largest KKT violation of a candidate lasso solution (0 at the optimum).
#' With g_j = x_j'(y - Xb)/n the conditions are:
#'   b_j != 0  ->  g_j = lambda * sign(b_j)
#'   b_j == 0  ->  |g_j| <= lambda
lasso_kkt_violation <- function(X, y, beta, lambda) {
  g <- as.vector(crossprod(X, y - X %*% beta)) / nrow(X)
  viol <- ifelse(beta != 0, abs(g - lambda * sign(beta)), pmax(abs(g) - lambda, 0))
  max(viol)
}

#' Decreasing lambda sequence from the smallest lambda that zeroes every
#' coefficient (lambda_max = max_j |x_j'y| / n) down by a factor `ratio`.
lambda_grid <- function(X, y, n_lambda = 25, ratio = 1e-3) {
  lmax <- max(abs(crossprod(X, y))) / nrow(X)
  exp(seq(log(lmax), log(lmax * ratio), length.out = n_lambda))
}

#' Lasso solutions along a DEcreasing lambda path, warm-starting each
#' fit from the previous one. Returns a p x L matrix.
lasso_path <- function(X, y, lambdas, ...) {
  B <- matrix(0, ncol(X), length(lambdas))
  beta <- NULL
  for (k in seq_along(lambdas)) {
    beta <- lasso_cd(X, y, lambdas[k], beta, ...)
    B[, k] <- beta
  }
  B
}

# ---- cross-validation --------------------------------------------------

#' K-fold CV over a DEcreasing lambda grid. `path_fn(X, y, lambdas)`
#' must return a p x L coefficient matrix. Returns the lambda with
#' minimum CV error and the "1-SE" lambda: the LARGEST lambda whose CV
#' error is within one standard error of the minimum (a sparser, more
#' conservative model).
kfold_cv <- function(X, y, path_fn, lambdas, K = 5, seed = 1) {
  set.seed(seed)
  n <- nrow(X)
  folds <- sample(rep(seq_len(K), length.out = n))
  err <- matrix(0, K, length(lambdas))
  for (k in seq_len(K)) {
    tr <- folds != k
    B <- path_fn(X[tr, , drop = FALSE], y[tr], lambdas)
    pred <- X[!tr, , drop = FALSE] %*% B
    err[k, ] <- colMeans((y[!tr] - pred)^2)
  }
  m <- colMeans(err)
  se <- apply(err, 2, sd) / sqrt(K)
  i_min <- which.min(m)
  i_1se <- min(which(m <= m[i_min] + se[i_min]))    # grid is decreasing, so smallest index = largest lambda
  list(lambda_min = lambdas[i_min], lambda_1se = lambdas[i_1se], cv_mean = m, cv_se = se)
}

# ---- exact ridge bias and variance (for checking the simulation) ------

#' Exact bias^2 and variance of ridge predictions on X_test, with the
#' training design X FIXED, true coefficients beta and noise sd sigma:
#'   b_hat = A y, A = (X'X/n + lambda I)^-1 X'/n
#'   E[X_test b_hat] = X_test A X beta,  Var = sigma^2 X_test A A' X_test'.
ridge_exact_bias_variance <- function(X, X_test, beta, sigma, lambda) {
  n <- nrow(X); p <- ncol(X)
  A <- solve(crossprod(X) / n + lambda * diag(p), t(X) / n)
  W <- X_test %*% A
  bias <- as.vector(W %*% (X %*% beta) - X_test %*% beta)
  c(bias2 = mean(bias^2), variance = sigma^2 * mean(rowSums(W^2)))
}
